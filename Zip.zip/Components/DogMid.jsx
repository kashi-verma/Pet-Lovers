const DogMid = () => {
    return (
      <>
         <div className="DogMid">
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className="dog_mid_col1">
                            <h2>Big Sale</h2>
                            <h2>Pet All Product</h2>
                            <p>Save Up to 30% All Product</p>
                            <button className="btn2">Shop Now</button>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="dog_mid_col2">
                            <h2>Save Up To 25%</h2>
                            <h2>On Every Order</h2>
                            <p>Pets Food And Equipments</p>
                            <button className=" btn2">Shop Now</button>
                            </div>
                    </div>
                </div>
            </div>

         </div>
      </>
    );
 };
    export default DogMid;